import Area_of_Triangle as tri
import Binary
import Calculator as clc
import Currency as Curr
import Dice
import factorial as fact
import Leapyear as Leap
import numberGuasing as guessing
import Password
import Quardatic_equation as Q
import script
import Palindrome as pal
import To_Do as t
import chatbot
import textadv
import Madlibs
import rockpaper
import quiz
import tic
import hangman as h


ch="y"
while ch.lower()=="y" or ch.lower()=="yes":
    print("1:TO find Triangle Area")
    print("2:Convert Number into Another system")
    print("3:TO Use Calculator")
    print("4:To Convert curreny ")
    print("5:To roll A dice")
    print("6:For Factorial")
    print("7:TO find Leap year ")
    print("8:TO Guess Number ")
    print("9:To Generate Password ")
    print("10:Quardatic equation")
    print("11:Timer ")
    print("12:To check Palindrome")
    print("13:TO DO List ")
    print("14:TO use Chatbot ")
    print("15:Text Based Adventure")
    print("16:Generate a paragraph ")
    print("17:TO Play Rock_Paper_Seccior ")
    print("18:TO Play Quiz ")
    print("19:To Play Tic_Tac_Toe ")
    print("20:TO Play Hangman ")
    print("99:Exit")
    print("------------------------------------------------------------------------------------")
    c=int(input("Please Enter No.:"))
    if c==1:
        tri.area()
        print("------------------------------------------------------------------------------------")
    elif c==2:
        Binary.main()
        print("------------------------------------------------------------------------------------")
    elif c==3:
        clc.calc()
        print("------------------------------------------------------------------------------------")
    elif c==4:
        Curr.main()
        print("------------------------------------------------------------------------------------")
    elif c==5:
        Dice.main()
        print("------------------------------------------------------------------------------------")
    elif c==6:
        fact.factorial()
        print("------------------------------------------------------------------------------------")
    elif c==7:
        Leap.main()
        print("------------------------------------------------------------------------------------")
    elif c==8:
        guessing.main()
        print("------------------------------------------------------------------------------------")
    elif c==9:
        Password.main()
        print("------------------------------------------------------------------------------------")
    elif c==10:
        Q.Q()
        print("------------------------------------------------------------------------------------")
    elif c==11:
        script.main()
        print("------------------------------------------------------------------------------------")
    elif c==12:
        pal.palindrome()
        print("------------------------------------------------------------------------------------")
    elif c==13:
        t.main()
        print("------------------------------------------------------------------------------------")
    elif c==14:
        chatbot.chatbot()
        print("------------------------------------------------------------------------------------")
    elif c==15:
        textadv.intro()
        textadv.forest()
        print("------------------------------------------------------------------------------------")
    elif c==16:
        madlibs.mad_libs()
        print("------------------------------------------------------------------------------------")
    elif c==17:
        rockpaper.play_game()
        print("------------------------------------------------------------------------------------")
    elif c==18:
        quiz.dev()
        print("------------------------------------------------------------------------------------")
    elif c==19:
        tic.play_game()
        print("------------------------------------------------------------------------------------")
    elif c==20:
        h.hangman()
        print("------------------------------------------------------------------------------------")
    



    elif c==99:
        print("Exiting Thank you for using ")
        c=int("Please Give Us Feedback(1-5)")
        if c<=3:

            print("Thank  You For Feedback We Will Try to Improve Next time ")
            break
        elif c>=3:
            print(f"Thank You For Giving Your Feedback {c}")
            break
        else :
            print("Exiting....")
            break
            
    else :
        
        print("Some Error Occured Please Discuss it TO Devesh Dixit And Utkarsh Sharma ")
    
        
        
        
