import random

def generate_password(length=12, use_uppercase=True, use_digits=True, use_special=True):
    lowercase_letters = 'abcdefghijklmnopqrstuvwxyz'
    uppercase_letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    digits = '0123456789'
    special_characters = '!@#$%^&*()_+-=[]{}|;:,.<>?'

    characters = lowercase_letters
    if use_uppercase:
        characters += uppercase_letters
    if use_digits:
        characters += digits
    if use_special:
        characters += special_characters

    generated_password = ''.join(random.choice(characters) for _ in range(length))
    return generated_password

def main():
    print("Welcome to Password Generator")
    length = int(input("Enter the length of the password (default is 12): ") or "12")
    use_uppercase = input("Include Uppercase Letters? (yes/no, default is yes): ").lower() in ('yes', 'y', '')
    use_digits = input("Include Digits? (yes/no, default is yes): ").lower() in ('yes', 'y', '')
    use_special = input("Include Special Characters? (yes/no, default is yes): ").lower() in ('yes', 'y', '')

    generated_password = generate_password(length, use_uppercase, use_digits, use_special)
    print("Generated Password:", generated_password)


