import random


words = ["python", "hangman", "program", "computer", "language", "code", "game", "developer", "algorithm"]

def choose_word(words):
    
    return random.choice(words)

def display_word(word, guessed_letters):
    
    displayed_word = ""
    for letter in word:
        if letter in guessed_letters:
            displayed_word += letter
        else:
            displayed_word += "_"
    return displayed_word

def hangman():
    
    word = choose_word(words)
    
    max_attempts = 6
    
    guessed_letters = []
    
    print("Welcome to Hangman!")
    
    while max_attempts > 0:
        print("\nWord:", display_word(word, guessed_letters))
        print("Attempts left:", max_attempts)
        
        
        guess = input("Guess a letter: ").lower()
        
        
        if len(guess) != 1 or not guess.isalpha():
            print("Please enter a single alphabetical character.")
            continue
        
        
        if guess in guessed_letters:
            print("You already guessed that letter.")
            continue
        
        guessed_letters.append(guess)
        
        if guess not in word:
            print("Incorrect guess!")
            max_attempts -= 1
        
        
        if display_word(word, guessed_letters) == word:
            print("\nCongratulations! You guessed the word:", word)
            break
    
    if max_attempts == 0:
        print("\nSorry, you ran out of attempts. The word was:", word)


