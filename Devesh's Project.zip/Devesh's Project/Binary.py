def convert_to_decimal(number, base):
    decimal = 0
    power = len(number) - 1
    for digit in number:
        if digit.isdigit():
            decimal += int(digit) * (base ** power)
        else:
            decimal += (ord(digit.upper()) - 55) * (base ** power)
        power -= 1
    return decimal

def convert_decimal_to_base(decimal, base):
    if decimal == 0:
        return '0'
    digits = ''
    while decimal:
        remainder = decimal % base
        if remainder < 10:
            digits = str(remainder) + digits
        else:
            digits = chr(remainder + 55) + digits
        decimal //= base
    return digits

def main():
    print("Welcome to Numeral System Converter")

    number = input("Enter a number: ")
    current_base = int(input("Enter the current base of the number (2, 8, 10, 16): "))
    new_base = int(input("Enter the base to convert to (2, 8, 10, 16): "))

    if current_base not in [2, 8, 10, 16] or new_base not in [2, 8, 10, 16]:
        print("Invalid base. Please enter either 2, 8, 10, or 16.")
        return

    decimal_number = convert_to_decimal(number, current_base)
    converted_number = convert_decimal_to_base(decimal_number, new_base)

    print(f"The equivalent of {number} in base {current_base} is: {converted_number} in base {new_base}")



