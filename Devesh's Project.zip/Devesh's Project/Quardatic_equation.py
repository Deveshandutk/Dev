
import cmath
def Q():
    a=int(input("Please enter Value of A:"))
    b=int(input("Please enter Value of b:"))
    c=int(input("Please enter Value of c:"))
    d = (b**2) - (4*a*c)


    sol1 = (-b-cmath.sqrt(d))/(2*a)
    sol2 = (-b+cmath.sqrt(d))/(2*a)

    print('The solution are {0} and {1}'.format(sol1,sol2))

