def mad_libs():
    
    story = "Once upon a time, there was a {adjective} {noun} who lived in a {place}. One day, the {noun} {verb} {adverb}."

    
    adjective = input("Enter an adjective: ")
    noun = input("Enter a noun: ")
    place = input("Enter a place: ")
    verb = input("Enter a verb: ")
    adverb = input("Enter an adverb: ")

    
    mad_libs_story = story.format(adjective=adjective, noun=noun, place=place, verb=verb, adverb=adverb)

    
    print("\nYour Mad Libs Story:\n")
    print(mad_libs_story)


