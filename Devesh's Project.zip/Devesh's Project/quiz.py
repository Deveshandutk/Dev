def ask_question(question, answer):
    user_answer = input(question + " ").strip().lower()
    return user_answer == answer.lower()

def run_quiz(questions):
    score = 0
    for question, answer in questions.items():
        if ask_question(question, answer):
            print("Correct!")
            score += 1
        else:
            print("Incorrect!")
    print(f"You scored {score} out of {len(questions)}.")

   
    
def dev():
     questions = {
        "What is the capital of France?": "Paris",
        "Who wrote 'Romeo and Juliet'?": "Shakespeare",
        "What is 2 + 2?": "4"
    }
     print("Welcome to the Quiz!")
     run_quiz(questions)

