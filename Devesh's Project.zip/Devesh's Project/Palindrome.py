def palindrome():
    s = input("Enter a string to check if it's a palindrome: ")
    s = s.replace(" ", "").lower()
    
    
    
    
    if s == s[::-1]:
        print("Yes, the string is a palindrome.")
    else:
        print("No, the string is not a palindrome.")
