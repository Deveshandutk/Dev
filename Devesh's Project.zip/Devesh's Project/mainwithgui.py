import tkinter as tk
from tkinter import messagebox
import Area_of_Triangle as tri
import Binary
import Calculator as clc
import Currency as Curr
import Dice
import factorial as fact
import Leapyear as Leap
import numberGuasing as guessing
import Password
import Quardatic_equation as Q
import script
import Palindrome as pal
import To_Do as t
import chatbot
import textadv
import Madlibs
import rockpaper
import quiz
import tic
import hangman as h

class App:
    def __init__(self, master):
        self.master = master
        self.master.title("Python Application")
        
        self.label = tk.Label(master, text="Welcome to Python Application")
        self.label.pack()

        self.button1 = tk.Button(master, text="Find Triangle Area", command=self.find_triangle_area)
        self.button1.pack()

        self.button2 = tk.Button(master, text="Convert Number into Another System", command=self.convert_number)
        self.button2.pack()

        self.button3 = tk.Button(master, text="Use Calculator", command=self.use_calculator)
        self.button3.pack()

        self.button4 = tk.Button(master, text="Convert Currency", command=self.convert_currency)
        self.button4.pack()

        self.button5 = tk.Button(master, text="Roll a Dice", command=self.roll_dice)
        self.button5.pack()

        self.button6 = tk.Button(master, text="Calculate Factorial", command=self.calculate_factorial)
        self.button6.pack()

        self.button7 = tk.Button(master, text="Check Leap Year", command=self.check_leap_year)
        self.button7.pack()

        self.button8 = tk.Button(master, text="Guess Number", command=self.guess_number)
        self.button8.pack()

        self.button9 = tk.Button(master, text="Generate Password", command=self.generate_password)
        self.button9.pack()

        self.button10 = tk.Button(master, text="Quadratic Equation", command=self.quadratic_equation)
        self.button10.pack()

        self.button11 = tk.Button(master, text="Timer", command=self.timer)
        self.button11.pack()

        self.button12 = tk.Button(master, text="Check Palindrome", command=self.check_palindrome)
        self.button12.pack()

        self.button13 = tk.Button(master, text="To-Do List", command=self.to_do_list)
        self.button13.pack()

        self.button14 = tk.Button(master, text="Use Chatbot", command=self.use_chatbot)
        self.button14.pack()

        self.button15 = tk.Button(master, text="Text Based Adventure", command=self.text_adventure)
        self.button15.pack()

        self.button16 = tk.Button(master, text="Generate a Paragraph", command=self.generate_paragraph)
        self.button16.pack()

        self.button17 = tk.Button(master, text="Play Rock, Paper, Scissors", command=self.play_rock_paper_scissors)
        self.button17.pack()

        self.button18 = tk.Button(master, text="Play Quiz", command=self.play_quiz)
        self.button18.pack()

        self.button19 = tk.Button(master, text="Play Tic-Tac-Toe", command=self.play_tic_tac_toe)
        self.button19.pack()

        self.button20 = tk.Button(master, text="Play Hangman", command=self.play_hangman)
        self.button20.pack()

        self.quit_button = tk.Button(master, text="Quit", command=master.quit)
        self.quit_button.pack()

    def find_triangle_area(self):
        tri.area()
        messagebox.showinfo("Result", "Triangle Area Calculated!")

    def convert_number(self):
        Binary.main()
        messagebox.showinfo("Result", "Number Converted!")

    def use_calculator(self):
        clc.calc()
        messagebox.showinfo("Result", "Calculator Closed!")

    def convert_currency(self):
        Curr.main()
        messagebox.showinfo("Result", "Currency Converted!")

    def roll_dice(self):
        Dice.main()
        messagebox.showinfo("Result", "Dice Rolled!")

    def calculate_factorial(self):
        fact.factorial()
        messagebox.showinfo("Result", "Factorial Calculated!")

    def check_leap_year(self):
        Leap.main()
        messagebox.showinfo("Result", "Leap Year Checked!")

    def guess_number(self):
        guessing.main()
        messagebox.showinfo("Result", "Number Guessed!")

    def generate_password(self):
        Password.main()
        messagebox.showinfo("Result", "Password Generated!")

    def quadratic_equation(self):
        Q.Q()
        messagebox.showinfo("Result", "Quadratic Equation Solved!")

    def timer(self):
        script.main()
        messagebox.showinfo("Result", "Timer Complete!")

    def check_palindrome(self):
        pal.palindrome()
        messagebox.showinfo("Result", "Palindrome Checked!")

    def to_do_list(self):
        t.main()
        messagebox.showinfo("Result", "To-Do List Opened!")

    def use_chatbot(self):
        chatbot.chatbot()
        messagebox.showinfo("Result", "Chatbot Closed!")

    def text_adventure(self):
        textadv.intro()
        textadv.forest()
        messagebox.showinfo("Result", "Text Adventure Complete!")

    def generate_paragraph(self):
        Madlibs.mad_libs()
        messagebox.showinfo("Result", "Paragraph Generated!")

    def play_rock_paper_scissors(self):
        rockpaper.play_game()
        messagebox.showinfo("Result", "Rock, Paper, Scissors Played!")

    def play_quiz(self):
        quiz.dev()
        messagebox.showinfo("Result", "Quiz Completed!")

    def play_tic_tac_toe(self):
        tic.play_game()
        messagebox.showinfo("Result", "Tic-Tac-Toe Played!")

    def play_hangman(self):
        h.hangman()
        messagebox.showinfo("Result", "Hangman Played!")

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
