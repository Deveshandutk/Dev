def convert_currency(amount, from_currency, to_currency):
    exchange_rates = {
        'USD': {'EUR': 0.83, 'GBP': 0.72, 'JPY': 105.63, 'AUD': 1.29, 'INR': 73.50},
        'EUR': {'USD': 1.21, 'GBP': 0.87, 'JPY': 127.31, 'AUD': 1.55, 'INR': 88.50},
        'GBP': {'USD': 1.39, 'EUR': 1.15, 'JPY': 146.12, 'AUD': 1.78, 'INR': 101.60},
        'JPY': {'USD': 0.0095, 'EUR': 0.0079, 'GBP': 0.0068, 'AUD': 0.012, 'INR': 0.71},
        'AUD': {'USD': 0.78, 'EUR': 0.64, 'GBP': 0.56, 'JPY': 83.12, 'INR': 55.89},
        'INR': {'USD': 0.014, 'EUR': 0.011, 'GBP': 0.0098, 'JPY': 1.41, 'AUD': 0.018}
    }

    if from_currency in exchange_rates and to_currency in exchange_rates[from_currency]:
        exchange_rate = exchange_rates[from_currency][to_currency]
        converted_amount = amount * exchange_rate
        return converted_amount
    else:
        print("Conversion not supported for the provided currencies.")
        return None

def main():
    print("Welcome to Simple Currency Converter")

    amount = float(input("Enter amount: "))
    from_currency = input("Enter source currency (e.g., USD): ").upper()
    to_currency = input("Enter target currency (e.g., EUR): ").upper()

    converted_amount = convert_currency(amount, from_currency, to_currency)
    if converted_amount is not None:
        print(f"{amount} {from_currency} is equivalent to {converted_amount:.2f} {to_currency}")


