import time

def countdown_timer(seconds):
    while seconds:
        mins, secs = divmod(seconds, 60)
        timer = '{:02d}:{:02d}'.format(mins, secs)
        print(timer)
        time.sleep(1)
        seconds -= 1

    print('Time is up!')

def main():
    print("Welcome to Countdown Timer")

    
    while True:
        try:
            seconds = int(input("Enter the number of seconds for the countdown: "))
            if seconds >= 0:
                break
            else:
                print("Please enter a non-negative integer.")
        except ValueError:
            print("Invalid input. Please enter a non-negative integer.")

    countdown_timer(seconds)



