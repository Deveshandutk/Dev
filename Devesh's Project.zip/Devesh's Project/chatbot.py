
responses = {
    "hi": "Hello!",
    "hello": "Hi there!",
    "how are you?": "I'm fine, thank you!",
    "what's your name?": "I'm a chatbot.",
    "bye": "Goodbye! Have a nice day!",
    "who made you": "Mr.Devesh Dixit and Utkarsh Sharma Made me ",
    "what can you do":"I can do many work But you have to train me First",
    
    "default": "I'm sorry, I didn't understand that."
}


def chatbot():
    print("Chatbot: Hi! How can I help you today?")
    while True:
        user_input = input("You: ").lower()
        if user_input == "quit":
            print("Chatbot: Goodbye!")
            break
        response = responses.get(user_input, responses["default"])
        print("Chatbot:", response)


