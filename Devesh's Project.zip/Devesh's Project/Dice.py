import random

def roll_dice(num_dice=1, num_sides=6):
    rolls = []
    for _ in range(num_dice):
        roll = random.randint(1, num_sides)
        rolls.append(roll)
    return rolls

def main():
    print("Welcome to the Dice Rolling Simulator")

    while True:
        num_dice = int(input("Enter the number of dice to roll: "))
        num_sides = int(input("Enter the number of sides for each die: "))

        if num_dice <= 0 or num_sides <= 0:
            print("Number of dice and number of sides should be greater than 0.")
            continue

        rolls = roll_dice(num_dice, num_sides)
        print("Rolling... Result:", rolls)

        play_again = input("Do you want to roll again? (yes/no): ").lower()
        if play_again != 'yes':
            print("Thank you for using the Dice Rolling Simulator. Goodbye!")
            break

