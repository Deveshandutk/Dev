import time

def intro():
    print("Welcome to the Text Adventure Game!")
    time.sleep(1)
    print("You find yourself in a mysterious forest.")
    time.sleep(1)
    print("Your goal is to find the treasure hidden deep within the forest.")
    time.sleep(1)
    print("Let the adventure begin!\n")

def forest():
    print("You are walking through the dense forest.")
    time.sleep(1)
    print("You hear strange noises around you.")
    time.sleep(1)
    print("You come across a fork in the road.")
    time.sleep(1)
    print("Do you want to go left or right?")

    choice = input("Enter 'left' or 'right': ").lower()
    if choice == "left":
        left_path()
    elif choice == "right":
        right_path()
    else:
        print("Invalid choice. Try again.")
        forest()

def left_path():
    print("You chose the left path.")
    time.sleep(1)
    print("You encounter a wild animal!")
    time.sleep(1)
    print("You have to fight it to proceed.")
    time.sleep(1)
    print("Do you want to 'fight' or 'run'?")

    choice = input("Enter 'fight' or 'run': ").lower()
    if choice == "fight":
        print("You defeated the wild animal and continue your journey.")
        treasure()
    elif choice == "run":
        print("You managed to escape from the wild animal.")
        forest()
    else:
        print("Invalid choice. Try again.")
        left_path()

def right_path():
    print("You chose the right path.")
    time.sleep(1)
    print("You encounter a river blocking your way.")
    time.sleep(1)
    print("Do you want to 'swim' across or 'look' for another way?")

    choice = input("Enter 'swim' or 'look': ").lower()
    if choice == "swim":
        print("You tried to swim across the river but got swept away by the current.")
        game_over()
    elif choice == "look":
        print("You found a bridge nearby and safely cross the river.")
        treasure()
    else:
        print("Invalid choice. Try again.")
        right_path()

def treasure():
    print("Congratulations! You found the hidden treasure!")
    time.sleep(1)
    print("You are victorious!")

def game_over():
    print("Game Over! You lost the game.")
    time.sleep(1)
    print("Try again next time.")


    
